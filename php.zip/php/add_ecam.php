!DOCTYPE html>
<html lang="en">
    <body>
        <form action="submit_ecam.php" method="post">
            <h2>User Registration</h2>
            <label for="indoor activity">IndoorActivity:</label>
            <input type="text" id="indooractivity" name="indooractivity" required> </br></br>
            <label for="outdoor activity">Outdoor Activity:</label>
            <input type="text" id="outdooractivity" name="outdooractivity" required> </br></br>
            <label for="date">DATE:</label>
            <input type="date" id="ex_date" name="ex_date" required> </br></br>
            
            
            <input type="submit" value="Register">

        </form>
</body>
</html>