<?php
// Include database connection
include 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $id = $_POST["id"];
    $name = $_POST["name"];
    $address = $_POST["address"];
    $currentcourse = $_POST["currentcourse"];
    $previouscourse = $_POST["previouscourse"];
    $phoneno = $_POST["phoneno"];
    $email = $_POST["email"];
    $document = $_POST["document"];


    // Update the user's information in the database
    $sql = "UPDATE sim SET name='$name', address='$address', currentcourse='$currentcourse', previouscourse='$previouscourse', phoneno='$phoneno', email='$email', document='$document' WHERE id=$id";

    // Execute the update query
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Close connection
$conn->close();
?>


